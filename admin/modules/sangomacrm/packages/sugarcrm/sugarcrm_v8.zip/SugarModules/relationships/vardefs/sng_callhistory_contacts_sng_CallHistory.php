<?php
// created: 2022-03-04 07:16:52
$dictionary["sng_CallHistory"]["fields"]["sng_callhistory_contacts"] = array (
  'name' => 'sng_callhistory_contacts',
  'type' => 'link',
  'relationship' => 'sng_callhistory_contacts',
  'source' => 'non-db',
  'module' => 'Contacts',
  'bean_name' => 'Contact',
  'vname' => 'LBL_SNG_CALLHISTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'id_name' => 'sng_callhistory_contactscontacts_idb',
);
