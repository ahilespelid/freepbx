<?php
 // created: 2022-03-04 07:16:52
$layout_defs["Leads"]["subpanel_setup"]['sng_callhistory_leads'] = array (
  'order' => 100,
  'module' => 'sng_CallHistory',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_SNG_CALLHISTORY_LEADS_FROM_SNG_CALLHISTORY_TITLE',
  'get_subpanel_data' => 'sng_callhistory_leads',
);
