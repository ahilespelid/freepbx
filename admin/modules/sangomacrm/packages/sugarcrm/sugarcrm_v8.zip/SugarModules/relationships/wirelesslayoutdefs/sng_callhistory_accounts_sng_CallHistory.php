<?php
 // created: 2022-03-04 07:16:52
$layout_defs["sng_CallHistory"]["subpanel_setup"]['sng_callhistory_accounts'] = array (
  'order' => 100,
  'module' => 'Accounts',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_SNG_CALLHISTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'get_subpanel_data' => 'sng_callhistory_accounts',
);
