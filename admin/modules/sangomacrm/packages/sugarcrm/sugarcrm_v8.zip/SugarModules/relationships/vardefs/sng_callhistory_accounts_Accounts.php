<?php
// created: 2022-03-04 07:16:52
$dictionary["Account"]["fields"]["sng_callhistory_accounts"] = array (
  'name' => 'sng_callhistory_accounts',
  'type' => 'link',
  'relationship' => 'sng_callhistory_accounts',
  'source' => 'non-db',
  'module' => 'sng_CallHistory',
  'bean_name' => false,
  'vname' => 'LBL_SNG_CALLHISTORY_ACCOUNTS_FROM_SNG_CALLHISTORY_TITLE',
  'id_name' => 'sng_callhistory_accountssng_callhistory_ida',
);
