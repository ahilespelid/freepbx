<?php
// created: 2022-03-04 07:16:52
$dictionary["Call"]["fields"]["sng_callhistory_calls"] = array (
  'name' => 'sng_callhistory_calls',
  'type' => 'link',
  'relationship' => 'sng_callhistory_calls',
  'source' => 'non-db',
  'module' => 'sng_CallHistory',
  'bean_name' => false,
  'vname' => 'LBL_SNG_CALLHISTORY_CALLS_FROM_SNG_CALLHISTORY_TITLE',
  'id_name' => 'sng_callhistory_callssng_callhistory_ida',
);
