<?php
 // created: 2022-03-04 07:16:52
$layout_defs["sng_CallHistory"]["subpanel_setup"]['sng_callhistory_calls'] = array (
  'order' => 100,
  'module' => 'Calls',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_SNG_CALLHISTORY_CALLS_FROM_CALLS_TITLE',
  'get_subpanel_data' => 'sng_callhistory_calls',
);
