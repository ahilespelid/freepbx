<?php
// created: 2022-03-04 07:16:52
$dictionary["sng_callhistory_leads"] = array (
  'true_relationship_type' => 'many-to-many',
  'relationships' => 
  array (
    'sng_callhistory_leads' => 
    array (
      'lhs_module' => 'sng_CallHistory',
      'lhs_table' => 'sng_callhistory',
      'lhs_key' => 'id',
      'rhs_module' => 'Leads',
      'rhs_table' => 'leads',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'sng_callhistory_leads_c',
      'join_key_lhs' => 'sng_callhistory_leadssng_callhistory_ida',
      'join_key_rhs' => 'sng_callhistory_leadsleads_idb',
    ),
  ),
  'table' => 'sng_callhistory_leads_c',
  'fields' => 
  array (
    'id' => 
    array (
      'name' => 'id',
      'type' => 'id',
    ),
    'date_modified' => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    'deleted' => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'default' => 0,
    ),
    'sng_callhistory_leadssng_callhistory_ida' => 
    array (
      'name' => 'sng_callhistory_leadssng_callhistory_ida',
      'type' => 'id',
    ),
    'sng_callhistory_leadsleads_idb' => 
    array (
      'name' => 'sng_callhistory_leadsleads_idb',
      'type' => 'id',
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'idx_sng_callhistory_leads_pk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'idx_sng_callhistory_leads_ida1_deleted',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'sng_callhistory_leadssng_callhistory_ida',
        1 => 'deleted',
      ),
    ),
    2 => 
    array (
      'name' => 'idx_sng_callhistory_leads_idb2_deleted',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'sng_callhistory_leadsleads_idb',
        1 => 'deleted',
      ),
    ),
    3 => 
    array (
      'name' => 'sng_callhistory_leads_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'sng_callhistory_leadssng_callhistory_ida',
        1 => 'sng_callhistory_leadsleads_idb',
      ),
    ),
  ),
);