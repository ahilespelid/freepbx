<?php
// created: 2022-03-04 07:16:52
$dictionary["sng_CallHistory"]["fields"]["sng_callhistory_accounts"] = array (
  'name' => 'sng_callhistory_accounts',
  'type' => 'link',
  'relationship' => 'sng_callhistory_accounts',
  'source' => 'non-db',
  'module' => 'Accounts',
  'bean_name' => 'Account',
  'vname' => 'LBL_SNG_CALLHISTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'id_name' => 'sng_callhistory_accountsaccounts_idb',
);
