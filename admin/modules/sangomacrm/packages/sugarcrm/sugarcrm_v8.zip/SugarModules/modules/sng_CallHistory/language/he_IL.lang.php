<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'קבוצות',
  'LBL_TEAMS' => 'קבוצות',
  'LBL_TEAM_ID' => 'Team Id',
  'LBL_ASSIGNED_TO_ID' => 'מזהה משתמש מוקצה',
  'LBL_ASSIGNED_TO_NAME' => 'משתמש',
  'LBL_TAGS_LINK' => 'תגיות',
  'LBL_TAGS' => 'תגיות',
  'LBL_ID' => 'מזהה',
  'LBL_DATE_ENTERED' => 'נוצר בתאריך',
  'LBL_DATE_MODIFIED' => 'שונה בתאריך',
  'LBL_MODIFIED' => 'נערך על ידי',
  'LBL_MODIFIED_ID' => 'שונה על ידי Id',
  'LBL_MODIFIED_NAME' => 'שונה על ידי ששמו',
  'LBL_CREATED' => 'נוצר על ידי',
  'LBL_CREATED_ID' => 'נוצר על ידי Id',
  'LBL_DOC_OWNER' => 'בעל המסמך',
  'LBL_USER_FAVORITES' => 'משתמשים שמעדיפים',
  'LBL_DESCRIPTION' => 'תיאור',
  'LBL_DELETED' => 'נמחק',
  'LBL_NAME' => 'שם',
  'LBL_CREATED_USER' => 'נוצר על ידי משתמש',
  'LBL_MODIFIED_USER' => 'שונה על ידי משתמש',
  'LBL_LIST_NAME' => 'שם',
  'LBL_EDIT_BUTTON' => 'ערוך',
  'LBL_REMOVE' => 'הסר',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'שונה על ידי משתמש',
  'LBL_LIST_FORM_TITLE' => 'Call History List',
  'LBL_MODULE_NAME' => 'Call History',
  'LBL_MODULE_TITLE' => 'Call History',
  'LBL_MODULE_NAME_SINGULAR' => 'Call History',
  'LBL_HOMEPAGE_TITLE' => 'שלי Call History',
  'LNK_NEW_RECORD' => 'צור Call History',
  'LNK_LIST' => 'View Call History',
  'LNK_IMPORT_SNG_CALLHISTORY' => 'Import Call History',
  'LBL_SEARCH_FORM_TITLE' => 'Search Call History',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'View History',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activities',
  'LBL_SNG_CALLHISTORY_SUBPANEL_TITLE' => 'Call History',
  'LBL_NEW_FORM_TITLE' => 'חדש Call History',
  'LNK_IMPORT_VCARD' => 'Import Call History vCard',
  'LBL_IMPORT' => 'Import Call History',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Call History record by importing a vCard from your file system.',
  'LBL_UNIQUEID' => 'uniqueid',
  'LBL_LINKEDID' => 'linkedid',
  'LBL_DATETIME' => 'Date',
  'LBL_DIRECTION' => 'Direction',
  'LBL_STATUS' => 'Status',
  'LBL_SRC' => 'Source',
  'LBL_DEST' => 'Destination',
  'LBL_DURATION' => 'Duration',
  'LBL_RECORDING' => 'Recording',
  'LBL_RECORDING_LOCATION' => 'Recording Location',
);