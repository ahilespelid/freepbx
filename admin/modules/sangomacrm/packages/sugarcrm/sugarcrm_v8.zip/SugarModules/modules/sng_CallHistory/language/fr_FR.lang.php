<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Équipes',
  'LBL_TEAMS' => 'Équipes',
  'LBL_TEAM_ID' => 'Équipe (ID)',
  'LBL_ASSIGNED_TO_ID' => 'ID utilisateur assigné',
  'LBL_ASSIGNED_TO_NAME' => 'Assigné à',
  'LBL_TAGS_LINK' => 'Tags',
  'LBL_TAGS' => 'Tags',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Date de création',
  'LBL_DATE_MODIFIED' => 'Date de modification',
  'LBL_MODIFIED' => 'Modifié par',
  'LBL_MODIFIED_ID' => 'Modifié par (ID)',
  'LBL_MODIFIED_NAME' => 'Modifié par Nom',
  'LBL_CREATED' => 'Créé par',
  'LBL_CREATED_ID' => 'Créé par (ID)',
  'LBL_DOC_OWNER' => 'Propriétaire du document',
  'LBL_USER_FAVORITES' => 'Favoris pour les utilisateurs suivants',
  'LBL_DESCRIPTION' => 'Description',
  'LBL_DELETED' => 'Supprimé',
  'LBL_NAME' => 'Nom',
  'LBL_CREATED_USER' => 'Créé par',
  'LBL_MODIFIED_USER' => 'Modifié par',
  'LBL_LIST_NAME' => 'Nom',
  'LBL_EDIT_BUTTON' => 'Éditer',
  'LBL_REMOVE' => 'Supprimer',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Modifié par Nom',
  'LBL_LIST_FORM_TITLE' => 'Call History Catalogue',
  'LBL_MODULE_NAME' => 'Call History',
  'LBL_MODULE_TITLE' => 'Call History',
  'LBL_MODULE_NAME_SINGULAR' => 'Call History',
  'LBL_HOMEPAGE_TITLE' => 'Mes Call History',
  'LNK_NEW_RECORD' => 'Créer Call History',
  'LNK_LIST' => 'Afficher Call History',
  'LNK_IMPORT_SNG_CALLHISTORY' => 'Import Call History',
  'LBL_SEARCH_FORM_TITLE' => 'Recherche Call History',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Historique',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activités',
  'LBL_SNG_CALLHISTORY_SUBPANEL_TITLE' => 'Call History',
  'LBL_NEW_FORM_TITLE' => 'Nouveau Call History',
  'LNK_IMPORT_VCARD' => 'Import Call History vCard',
  'LBL_IMPORT' => 'Import Call History',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Call History record by importing a vCard from your file system.',
  'LBL_UNIQUEID' => 'uniqueid',
  'LBL_LINKEDID' => 'linkedid',
  'LBL_DATETIME' => 'Date',
  'LBL_DIRECTION' => 'Direction',
  'LBL_STATUS' => 'Status',
  'LBL_SRC' => 'Source',
  'LBL_DEST' => 'Destination',
  'LBL_DURATION' => 'Duration',
  'LBL_RECORDING' => 'Recording',
  'LBL_RECORDING_LOCATION' => 'Recording Location',
);