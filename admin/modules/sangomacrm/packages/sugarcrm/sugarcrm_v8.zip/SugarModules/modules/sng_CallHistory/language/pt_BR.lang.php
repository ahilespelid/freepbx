<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Equipes',
  'LBL_TEAMS' => 'Equipes',
  'LBL_TEAM_ID' => 'Id da Equipe',
  'LBL_ASSIGNED_TO_ID' => 'ID do usuário atribuído',
  'LBL_ASSIGNED_TO_NAME' => 'Atribuído a',
  'LBL_TAGS_LINK' => 'Marcações',
  'LBL_TAGS' => 'Marcações',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Data de criação',
  'LBL_DATE_MODIFIED' => 'Data da Modificação',
  'LBL_MODIFIED' => 'Modificado Por',
  'LBL_MODIFIED_ID' => 'Modificado Por Id',
  'LBL_MODIFIED_NAME' => 'Modificado por nome',
  'LBL_CREATED' => 'Criado Por',
  'LBL_CREATED_ID' => 'Criado Por Id',
  'LBL_DOC_OWNER' => 'Proprietário do documento',
  'LBL_USER_FAVORITES' => 'Usuários Favoritos',
  'LBL_DESCRIPTION' => 'Descrição',
  'LBL_DELETED' => 'Excluído',
  'LBL_NAME' => 'Nome',
  'LBL_CREATED_USER' => 'Criado pelo usuário',
  'LBL_MODIFIED_USER' => 'Modificado pelo usuário',
  'LBL_LIST_NAME' => 'Nome',
  'LBL_EDIT_BUTTON' => 'Editar',
  'LBL_REMOVE' => 'Remover',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Modificado por nome',
  'LBL_LIST_FORM_TITLE' => 'Call History Lista',
  'LBL_MODULE_NAME' => 'Call History',
  'LBL_MODULE_TITLE' => 'Call History',
  'LBL_MODULE_NAME_SINGULAR' => 'Call History',
  'LBL_HOMEPAGE_TITLE' => 'Minha Call History',
  'LNK_NEW_RECORD' => 'Criar Call History',
  'LNK_LIST' => 'Visualização Call History',
  'LNK_IMPORT_SNG_CALLHISTORY' => 'Import Call History',
  'LBL_SEARCH_FORM_TITLE' => 'Pesquisar Call History',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Ver histórico',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Cadeia de atividades',
  'LBL_SNG_CALLHISTORY_SUBPANEL_TITLE' => 'Call History',
  'LBL_NEW_FORM_TITLE' => 'Novo Call History',
  'LNK_IMPORT_VCARD' => 'Import Call History vCard',
  'LBL_IMPORT' => 'Import Call History',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Call History record by importing a vCard from your file system.',
  'LBL_UNIQUEID' => 'uniqueid',
  'LBL_LINKEDID' => 'linkedid',
  'LBL_DATETIME' => 'Date',
  'LBL_DIRECTION' => 'Direction',
  'LBL_STATUS' => 'Status',
  'LBL_SRC' => 'Source',
  'LBL_DEST' => 'Destination',
  'LBL_DURATION' => 'Duration',
  'LBL_RECORDING' => 'Recording',
  'LBL_RECORDING_LOCATION' => 'Recording Location',
);