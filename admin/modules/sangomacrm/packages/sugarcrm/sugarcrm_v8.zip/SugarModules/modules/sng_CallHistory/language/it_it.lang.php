<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Gruppi',
  'LBL_TEAMS' => 'Gruppi',
  'LBL_TEAM_ID' => 'Id Gruppo',
  'LBL_ASSIGNED_TO_ID' => 'Assegnato a ID:',
  'LBL_ASSIGNED_TO_NAME' => 'Assegnato a:',
  'LBL_TAGS_LINK' => 'Tag',
  'LBL_TAGS' => 'Tag',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Data Inserimento',
  'LBL_DATE_MODIFIED' => 'Data Modifica',
  'LBL_MODIFIED' => 'Modificato da',
  'LBL_MODIFIED_ID' => 'Modificato da Id',
  'LBL_MODIFIED_NAME' => 'Modificato da Nome',
  'LBL_CREATED' => 'Creato da',
  'LBL_CREATED_ID' => 'Creato da Id',
  'LBL_DOC_OWNER' => 'Proprietario del documento',
  'LBL_USER_FAVORITES' => 'Preferenze Utenti',
  'LBL_DESCRIPTION' => 'Descrizione',
  'LBL_DELETED' => 'Eliminato',
  'LBL_NAME' => 'Nome',
  'LBL_CREATED_USER' => 'Creato da utente',
  'LBL_MODIFIED_USER' => 'Modificato da utente',
  'LBL_LIST_NAME' => 'Nome',
  'LBL_EDIT_BUTTON' => 'Modifica',
  'LBL_REMOVE' => 'Rimuovi',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Modificato dal Nome',
  'LBL_LIST_FORM_TITLE' => 'Call History Lista',
  'LBL_MODULE_NAME' => 'Call History',
  'LBL_MODULE_TITLE' => 'Call History',
  'LBL_MODULE_NAME_SINGULAR' => 'Call History',
  'LBL_HOMEPAGE_TITLE' => 'Mio Call History',
  'LNK_NEW_RECORD' => 'Crea Call History',
  'LNK_LIST' => 'Visualizza Call History',
  'LNK_IMPORT_SNG_CALLHISTORY' => 'Import Call History',
  'LBL_SEARCH_FORM_TITLE' => 'Ricerca Call History',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Cronologia',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Attività',
  'LBL_SNG_CALLHISTORY_SUBPANEL_TITLE' => 'Call History',
  'LBL_NEW_FORM_TITLE' => 'Nuovo Call History',
  'LNK_IMPORT_VCARD' => 'Import Call History vCard',
  'LBL_IMPORT' => 'Import Call History',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Call History record by importing a vCard from your file system.',
  'LBL_UNIQUEID' => 'uniqueid',
  'LBL_LINKEDID' => 'linkedid',
  'LBL_DATETIME' => 'Date',
  'LBL_DIRECTION' => 'Direction',
  'LBL_STATUS' => 'Status',
  'LBL_SRC' => 'Source',
  'LBL_DEST' => 'Destination',
  'LBL_DURATION' => 'Duration',
  'LBL_RECORDING' => 'Recording',
  'LBL_RECORDING_LOCATION' => 'Recording Location',
);