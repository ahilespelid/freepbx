<?php
// created: 2022-03-04 07:16:52
$viewdefs['sng_CallHistory']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_SNG_CALLHISTORY_LEADS_FROM_LEADS_TITLE',
  'context' => 
  array (
    'link' => 'sng_callhistory_leads',
  ),
);