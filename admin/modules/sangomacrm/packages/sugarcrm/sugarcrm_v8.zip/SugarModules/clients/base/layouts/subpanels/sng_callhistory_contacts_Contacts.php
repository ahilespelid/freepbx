<?php
// created: 2022-03-04 07:16:52
$viewdefs['Contacts']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_SNG_CALLHISTORY_CONTACTS_FROM_SNG_CALLHISTORY_TITLE',
  'context' => 
  array (
    'link' => 'sng_callhistory_contacts',
  ),
);