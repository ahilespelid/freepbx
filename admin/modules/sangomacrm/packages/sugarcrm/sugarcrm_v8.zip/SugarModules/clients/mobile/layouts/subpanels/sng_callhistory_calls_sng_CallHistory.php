<?php
// created: 2022-03-04 07:16:52
$viewdefs['sng_CallHistory']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_SNG_CALLHISTORY_CALLS_FROM_CALLS_TITLE',
  'context' => 
  array (
    'link' => 'sng_callhistory_calls',
  ),
);