<?php
// created: 2022-03-04 07:16:52
$viewdefs['Calls']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_SNG_CALLHISTORY_CALLS_FROM_SNG_CALLHISTORY_TITLE',
  'context' => 
  array (
    'link' => 'sng_callhistory_calls',
  ),
);