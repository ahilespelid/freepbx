<?php

//$mi = new ModuleInstaller();
//$mi->merge_files('Ext/Include/', 'modules.ext.php', '', true);
//$mi->install_beans(array('sng_CallHistory'));

/*
require_once('modules/Administration/QuickRepairAndRebuild.php');
$rac = new RepairAndClear();
$selectedActions = array(
			'clearTpls',
			'clearJsFiles',
			'clearDashlets',
			'clearVardefs',
			'clearJsLangFiles',
			'rebuildAuditTables',
			'repairDatabase',
		);
$rac->repairAndClearAll($selectedActions, array(translate('LBL_ALL_MODULES')),true, false);
//$mi->rebuild_all();
*/
