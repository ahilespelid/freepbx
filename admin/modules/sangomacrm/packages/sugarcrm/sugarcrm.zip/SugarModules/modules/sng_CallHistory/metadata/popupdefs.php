<?php
$popupMeta = array (
    'moduleMain' => 'sng_CallHistory',
    'varName' => 'sng_CallHistory',
    'orderBy' => 'sng_callhistory.name',
    'whereClauses' => array (
  'name' => 'sng_callhistory.name',
),
    'searchInputs' => array (
  0 => 'sng_callhistory_number',
  1 => 'name',
  2 => 'priority',
  3 => 'status',
),
    'listviewdefs' => array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
),
);
