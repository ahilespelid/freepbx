<?php
// created: 2016-10-24 00:40:32
$dictionary["sng_CallHistory"]["fields"]["sng_callhistory_accounts"] = array (
  'name' => 'sng_callhistory_accounts',
  'type' => 'link',
  'relationship' => 'sng_callhistory_accounts',
  'source' => 'non-db',
  'module' => 'Accounts',
  'bean_name' => 'Account',
  'vname' => 'LBL_SNG_CALLHISTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
