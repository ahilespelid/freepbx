<?php
//$mi = new ModuleInstaller();
//$mi->merge_files('Ext/Include/', 'modules.ext.php');
