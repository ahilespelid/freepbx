<?php
 //WARNING: The contents of this file are auto-generated
/*
global $beanList;
global $beanFiles;
global $moduleList;
$beanList['sng_CallHistory'] = 'sng_CallHistory';
$beanFiles['sng_CallHistory'] = 'modules/sng_CallHistory/sng_CallHistory.php';
$moduleList[] = 'sng_CallHistory';

$mi = new ModuleInstaller();
$mi->install_beans(array('sng_CallHistory'));
*/
